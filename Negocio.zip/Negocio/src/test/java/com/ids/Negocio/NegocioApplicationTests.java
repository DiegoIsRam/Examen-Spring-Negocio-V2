package com.ids.Negocio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NegocioApplicationTests {

	@Test
	void contextLoads() {
	}

}
